package com.cg.capstore.exception;

public class CapStoreException extends Exception{

	public CapStoreException() {
		super();
	}
	public CapStoreException(String message) {
		super(message);
	}
}
