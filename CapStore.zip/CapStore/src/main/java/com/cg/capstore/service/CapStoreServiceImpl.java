package com.cg.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.capstore.bean.CapStore;
import com.cg.capstore.dao.CapStoreDao;
import com.cg.capstore.exception.CapStoreException;

@Service
public class CapStoreServiceImpl implements CapStoreService{

	@Autowired
	CapStoreDao capStoreDao;
	@Override
	public List<CapStore> addCapStore(CapStore products) throws CapStoreException {
		try {
			capStoreDao.save(products);
			return capStoreDao.findAll();
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	@Override
	public List<CapStore> getAllCapStoreDetials() throws CapStoreException {
		try {
			return capStoreDao.findAll();
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	@Override
	public List<CapStore> getPlacedProducts(String ordStatus) throws CapStoreException {
		try {
			if(ordStatus.equals("pld"))
				return capStoreDao.getPlacedProducts(ordStatus);
			else {
				throw new CapStoreException("invalid option");
			}
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	@Override
	public List<CapStore> getDispatchedProducts(String ordStatus) throws CapStoreException {
		try {
			if(ordStatus.equals("disp"))
			return capStoreDao.getDispatchedProducts(ordStatus);
			else {
				throw new CapStoreException("invalid option");
			}
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	@Override
	public List<CapStore> updatePlacedProducts(String ordId, String ordStatus) throws CapStoreException {
		try {
			Optional<CapStore> optional=capStoreDao.findById(ordId);
			if(ordStatus.equals("pld")) {
				CapStore placed=optional.get();
				placed.setOrdStatus("disp");
				capStoreDao.save(placed);
				return capStoreDao.getPlacedProducts(ordStatus);
			}
			else {
				throw new CapStoreException("invalid option");
			}
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
		
	}

	@Override
	public List<CapStore> updateDispatchedProducts(String ordId, String ordStatus) throws CapStoreException {
		try {
			Optional<CapStore> optional=capStoreDao.findById(ordId);
			if(ordStatus.equals("disp")) {
				CapStore dispatched=optional.get();
				dispatched.setOrdStatus("Rec");
				capStoreDao.save(dispatched);
				return capStoreDao.getPlacedProducts(ordStatus);
			}
			else {
				throw new CapStoreException("invalid option");
			}
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	@Override
	public List<CapStore> updateAllProducts(String ordId, String ordStatus) throws CapStoreException {
		try {
			Optional<CapStore> optional=capStoreDao.findById(ordId);
			if(ordStatus.equalsIgnoreCase("pld")) {
				CapStore dispatched=optional.get();
				dispatched.setOrdStatus("disp");
				capStoreDao.save(dispatched);
				return capStoreDao.getPlacedProducts(ordStatus);
			}
			else if(ordStatus.equalsIgnoreCase("disp")) {
				CapStore dispatched=optional.get();
				dispatched.setOrdStatus("Rec");
				capStoreDao.save(dispatched);
				return capStoreDao.getPlacedProducts(ordStatus);
			}
			else
				throw new CapStoreException("Invalid option");
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}


}
