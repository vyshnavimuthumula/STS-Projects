package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.bean.CapStore;
import com.cg.capstore.exception.CapStoreException;

public interface CapStoreService {

	public List<CapStore> addCapStore(CapStore products) throws CapStoreException;
	public List<CapStore> getAllCapStoreDetials() throws CapStoreException;
	public List<CapStore> getDispatchedProducts(String ordStatus) throws CapStoreException;
	public List<CapStore> getPlacedProducts(String ordStatus) throws CapStoreException;
	public List<CapStore> updatePlacedProducts(String ordId,String ordStatus) throws CapStoreException;
	public List<CapStore> updateDispatchedProducts(String ordId,String ordStatus) throws CapStoreException;
	public List<CapStore> updateAllProducts(String ordId,String ordStatus) throws CapStoreException;
}
