package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.bean.CapStore;
import com.cg.capstore.exception.CapStoreException;
import com.cg.capstore.service.CapStoreService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CapStoreController {
	
	@Autowired
	CapStoreService capStoreService;
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public List<CapStore> addCapStore(@RequestBody CapStore products) throws CapStoreException{
		return capStoreService.addCapStore(products);
	}
	@RequestMapping("/capstore")
	public List<CapStore> getAllCapStoreDetials() throws CapStoreException{
		return capStoreService.getAllCapStoreDetials();
	}
	@RequestMapping(value="/placedproducts/{ordStatus}")
	public List<CapStore> getProducts(@PathVariable String ordStatus) throws CapStoreException{
		return capStoreService.getPlacedProducts(ordStatus);
	}
	@RequestMapping(value="/dispatchedproducts/{ordStatus}")
	public List<CapStore> getDispatchedProducts(@PathVariable String ordStatus) throws CapStoreException{
		return capStoreService.getDispatchedProducts(ordStatus);
	}
	@RequestMapping(value="/updatePlacedProducts/{ordId}/{ordStatus}",method=RequestMethod.GET)
	public List<CapStore> updatePlacedProducts(@PathVariable String ordId,@PathVariable String ordStatus) throws CapStoreException{
		return capStoreService.updatePlacedProducts(ordId,ordStatus);
	}
	@RequestMapping(value="/updateDispatchedProducts/{ordId}/{ordStatus}",method=RequestMethod.GET)
	public List<CapStore> updateDispatchedProducts(@PathVariable String ordId,@PathVariable String ordStatus) throws CapStoreException{
		return capStoreService.updateDispatchedProducts(ordId,ordStatus);
	}
	@RequestMapping(value="/updateProduct/{ordId}/{ordStatus}",method=RequestMethod.GET)
	public List<CapStore> updateAllProducts(@PathVariable String ordId,@PathVariable String ordStatus) throws CapStoreException{
		return capStoreService.updateAllProducts(ordId,ordStatus);
	}

}
