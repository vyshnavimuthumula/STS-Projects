package com.cg.capstore.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.capstore.exception.CapStoreException;




@ControllerAdvice
public class CapStoreExceptionHandler {

	@ExceptionHandler(CapStoreException.class)
	public ResponseEntity<String> handleException(Exception ex){
		return new ResponseEntity<String>("Error: " + ex.getMessage(),HttpStatus.CONFLICT);
		
	}
}
