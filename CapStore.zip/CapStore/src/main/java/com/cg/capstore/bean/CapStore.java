package com.cg.capstore.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CapStore {

	@Id
	 private String ordId;
	 private String merId;
	 private String custId;
	 private String proId;	
	 private String ordPrice;
	 private int ordQty;
	 private String ordStatus;
	public String getOrdId() {
		return ordId;
	}
	public void setOrdId(String ordId) {
		this.ordId = ordId;
	}
	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getProId() {
		return proId;
	}
	public void setProId(String proId) {
		this.proId = proId;
	}
	public String getOrdPrice() {
		return ordPrice;
	}
	public void setOrdPrice(String ordPrice) {
		this.ordPrice = ordPrice;
	}
	public int getOrdQty() {
		return ordQty;
	}
	public void setOrdQty(int ordQty) {
		this.ordQty = ordQty;
	}
	public String getOrdStatus() {
		return ordStatus;
	}
	public void setOrdStatus(String ordStatus) {
		this.ordStatus = ordStatus;
	}
	@Override
	public String toString() {
		return "CapStore [ordId=" + ordId + ", merId=" + merId + ", custId=" + custId + ", proId=" + proId
				+ ", ordPrice=" + ordPrice + ", ordQty=" + ordQty + ", ordStatus=" + ordStatus + "]";
	}
	 

}
