package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.CapStore;

@Repository
public interface CapStoreDao extends JpaRepository<CapStore, String>{

	@Query("from CapStore where ordStatus=:ordStatus")
	List<CapStore> getPlacedProducts(String ordStatus);
	@Query("from CapStore where ordStatus=:ordStatus2")
	List<CapStore> getDispatchedProducts(@Param("ordStatus2") String ordStatus);
	@Query("from CapStore where ordId=:ordId and ordStatus=:ordStatus")
	List<CapStore> updatePlacedProducts(String ordId, String ordStatus);
	@Query("from CapStore where ordId=:ordId2 and ordStatus=:ordStatus2")
	List<CapStore> updateDispatchedProducts(@Param("ordId2") String ordId, @Param("ordStatus2") String ordStatus);
	@Query("from CapStore where ordId=:ordId3 and ordStatus=:ordStatus3")
	List<CapStore> updateAllProducts(@Param("ordId3") String ordId, @Param("ordStatus3") String ordStatus);
}
