package com.cg.session.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;



@Entity
@Table(name="sessionmanagement")
public class Session {

	/*
	Author : Vyshnavi Muthumula
	Date of Duration : 30/1/2019
	Purpose : Here we are validating the session details, session and mode are using min and max for fixing the size and pattern is for only taking two values i.e ILT and VC
	*/
	
	@Id
	@SequenceGenerator(name="sessionId",sequenceName="session_seq",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="sessionId")
	private int id;
	private String name;
	@Min(0)
	@Max(3)
	private int duration;
	private String faculty;
	@Column(name="mode1")
	@Pattern(regexp="(ILT|VC)")
	private String mode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	@Override
	public String toString() {
		return "Session [id=" + id + ", name=" + name + ", duration=" + duration + ", faculty=" + faculty + ", mode="
				+ mode + "]";
	}
	
}
