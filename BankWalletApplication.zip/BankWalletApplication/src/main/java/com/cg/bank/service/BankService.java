package com.cg.bank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.bean.Bank;
import com.cg.bank.dao.BankDao;
import com.cg.bank.exception.BankException;



@Service
public class BankService implements IBankService{

	@Autowired
	BankDao bankDao;
	@Override
	public List<Bank> addBank(Bank bankcustomer) throws BankException {
		try {
			bankDao.save(bankcustomer);
			return bankDao.findAll();
		}catch(Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public List<Bank> getAllBankDetials() throws BankException {
		try {
			return bankDao.findAll();
		}catch(Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public int showBalance(int accountnum) throws BankException {
		try {
			return bankDao.findById(accountnum).get().getBalance();
		}catch(Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public int depositMoney(int accountnum, int amount) throws BankException {
		try {
			Optional<Bank> optional=bankDao.findById(accountnum);
			Bank deposit=optional.get();
			deposit.setBalance(optional.get().getBalance()+amount);
			bankDao.save(deposit);
			return bankDao.findById(accountnum).get().getBalance();
		}catch(Exception e) {
			throw new BankException(e.getMessage());
		}
		
	}


	@Override
	public int withdrawMoney(int accountnum, int amount) throws BankException {
		try{
			Optional<Bank> optional=bankDao.findById(accountnum);
			if(optional.isPresent()) {
				Bank withdraw=optional.get();
				withdraw.setBalance(withdraw.getBalance()-amount);
				bankDao.save(withdraw);
				return bankDao.findById(accountnum).get().getBalance();
			}
			else
			{
				throw new BankException("Customer with accountnumber " + accountnum + " does not exit");
			}
		}catch(Exception e) {
			throw new BankException(e.getMessage());
		}
	}
	
	
	@Override
	public int fundTransfer(int accountnum1, int accountnum2, int amount) throws BankException {
		try{
			Optional<Bank> optional1=bankDao.findById(accountnum1);
			Optional<Bank> optional2=bankDao.findById(accountnum2);
			if(optional1.isPresent() && optional2.isPresent()) {
				Bank deposit=optional1.get();
				Bank credit=optional2.get();
				deposit.setBalance(deposit.getBalance()-amount);
				credit.setBalance(deposit.getBalance()+amount);
				bankDao.save(deposit);
				bankDao.save(credit);
				return bankDao.findById(accountnum1).get().getBalance();
			}
			else
			{
				throw new BankException("Customer with accountnumber " + accountnum1 + " does not exit");
			}
		}catch(Exception e) {
			throw new BankException(e.getMessage());
		}
	}

//	@Override
//	public Boolean getCustomerByLoginDetails(String username, String password) throws BankException {
//		 try {
//		        Boolean bank = bankDao.getUsernameByLogin(username);
//		        bankDao.getPasswordByLogin(password);
//		        return bank;
//		        }
//		        catch(Exception e) {
//		            throw new BankException("Invalid Username and Password");
//		        }
//	}	
//	

}
